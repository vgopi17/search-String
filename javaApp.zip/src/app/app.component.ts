import { Component } from '@angular/core';
import { SearchService } from './services/search.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'javaApp';
  sentence :String;
  searchStr:String;

  constructor(private searchServ : SearchService){

  }

  searchString(){
    console.log(this.sentence+','+this.searchStr);

    this.searchServ.searchStr(this.sentence,this.searchStr).subscribe(data=>
      console.log(data));

  }
}
