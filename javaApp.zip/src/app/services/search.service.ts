import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  searchURL='http://localhost:8999/api/v1';
  options = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'

    })
  };
  constructor(private http: HttpClient) { }
  
  searchStr(sentence:String, str: String){

    return this.http.get(this.searchURL+'/search?sentence='+sentence+'&str='+str,this.options);
  }
}
