package com.example.search.service;

import org.springframework.stereotype.Service;

import java.util.List;


public interface SearchService {

    public List<Integer> searchStr(String sentence, String str);
}
