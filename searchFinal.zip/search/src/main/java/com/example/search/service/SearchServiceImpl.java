package com.example.search.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class SearchServiceImpl implements SearchService{

    public List<Integer> searchStr(String sentence, String str){


//        String str = "vaish";
//        String sentence = "vaish123456vaish2344";

        char[] charArray = sentence.toCharArray();
        int strLen = str.length();

        List<Integer> strLengths = new ArrayList<>();
        int l=0;
        int count=0;
        int latestInd=0;
        int flag=0;
        while(l<charArray.length)
        {

            //System.out.println(charArray[l]+","+sentence.charAt(0));

            if(l + strLen<charArray.length && sentence.substring(l,l+strLen).equals(str)) {
                //System.out.println(sentence.substring(l, l + strLen).equals(str));

                int startInd = l + strLen ;

                count = 0;
                latestInd = l + strLen;

                while (latestInd+strLen +1< charArray.length && !sentence.substring(latestInd, latestInd + strLen).equals(str)) {

                    count += 1;
                    l++;
                    latestInd += 1;
                }
                while(latestInd<charArray.length && latestInd+strLen+ 1 > charArray.length){
                    count+=1;
                    l++;
                    latestInd++;
                    flag=1;

                }

                //System.out.println(count);
                strLengths.add(count);
                l=latestInd;

            }
            else
                l=l+1;
            if(flag==1)
                break;

        }



        System.out.println(strLengths.toString());
        return strLengths;


    }


}
