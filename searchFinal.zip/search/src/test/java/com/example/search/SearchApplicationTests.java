package com.example.search;
import com.example.search.controller.SearchController;
import com.example.search.service.SearchService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SearchApplication.class})
@AutoConfigureMockMvc
class SearchApplicationTests {

    @Test
    void contextLoads() {
    }

    @Autowired
    SearchController searchController;


    private static ObjectMapper objectMapper = new ObjectMapper();
    @Autowired
    private MockMvc mockMvc;

    public void stringSearch(){

        String sentence="vai1245136236tvai26382783";
        String str="vai";
        MvcResult result = null;
        try {
            result = mockMvc.perform(get("/api/v1/defects/search")
                    .param("sentence",sentence)
                    .param("str",str)
                    .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.*").exists())
                    .andReturn();

            String respBody = result.getResponse().getContentAsString();
            System.out.println("JSON Data : "+respBody);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
